//
//  CustomerAddView.swift
//  SqliteDemoApp
//
//  Created by Manish Surti on 15/07/2017.
//  Copyright © 2017 ASquare.com. All rights reserved.
//

import UIKit

class CustomerAddView: UIViewController {

    var customerArray : NSMutableArray = NSMutableArray()
    @IBOutlet weak var txtname: UITextField!
    @IBOutlet weak var txtage: UITextField!
    @IBOutlet weak var txtaddress: UITextField!
    @IBOutlet weak var txtsalary: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

      
    }


    @IBAction func CustomerAddACtion(_ sender: Any) {
       
        if(txtname.text == "")
        {
            Util.invokeAlertMethod(strTitle: "", strBody: "Please enter customer name.", delegate: nil)
        }
        else if(txtage.text == "")
        {
            Util.invokeAlertMethod(strTitle: "", strBody: "Please enter customer age.", delegate: nil)
        }
        else if(txtaddress.text == "")
        {
            Util.invokeAlertMethod(strTitle: "", strBody: "Please enter customer address.", delegate: nil)
        }
        else if(txtsalary.text == "")
        {
            Util.invokeAlertMethod(strTitle: "", strBody: "Please enter customer salary.", delegate: nil)
        }
        else{
            let customerInfo: CustomerInfo = CustomerInfo()
            customerInfo.custName = txtname.text!
            customerInfo.custAge = Int(txtage.text!)!
            customerInfo.custAddress = txtaddress.text!
            customerInfo.custSalary = Float(txtsalary.text!)!
            
            let isInserted = ModelManager.getInstance().addCustomerData(custInfo: customerInfo)
            if isInserted {
                Util.invokeAlertMethod(strTitle: "", strBody: "Record Inserted successfully.", delegate: nil)
            } else {
                Util.invokeAlertMethod(strTitle: "", strBody: "Error in inserting record.", delegate: nil)
            }
        }
        //self.navigationController?.popViewController(animated: true)
        
    }
    @IBAction func ShowdataAction(_ sender: Any) {
        
        customerArray = ModelManager.getInstance().getCustomerdata()
        for i in 0..<customerArray.count{
            
            let custinfo : CustomerInfo = customerArray.object(at: i) as! CustomerInfo
            print(custinfo.custName , custinfo.custAddress, custinfo.custAge ,custinfo.custSalary,custinfo.custid)
            
        }
        
        //let student:StudentInfo = marrStudentData.object(at: indexPath.row) as! StudentInfo
        //cell.lblContent.text = "Name : \(student.fname)  \n  Marks )"
    }
    
}
