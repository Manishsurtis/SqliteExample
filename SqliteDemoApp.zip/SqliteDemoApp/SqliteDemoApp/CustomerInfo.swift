//
//  CustomerInfo.swift
//  SqliteDemoApp
//
//  Created by Manish Surti on 15/07/2017.
//  Copyright © 2017 ASquare.com. All rights reserved.
//

import UIKit

class CustomerInfo: NSObject {
    
    var custid : Int = Int()
    var custName : String = String()
    var custAge : Int = Int()
    var custAddress:String = String()
    var custSalary : Float = Float()
}
