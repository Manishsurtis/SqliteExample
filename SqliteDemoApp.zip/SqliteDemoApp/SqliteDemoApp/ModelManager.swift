//
//  ModelManager.swift
//  DataBaseDemo
//
//  Created by Krupa-iMac on 05/08/14.
//  Copyright (c) 2014 TheAppGuruz. All rights reserved.
//

import UIKit

let sharedInstance = ModelManager()

class ModelManager: NSObject {
    
    var database: FMDatabase? = nil

    class func getInstance() -> ModelManager
    {
        if(sharedInstance.database == nil)
        {
            sharedInstance.database = FMDatabase(path: Util.getPath(fileName: "OrderManage.sqlite"))
        }
        return sharedInstance
    }
    
    func addCustomerData(custInfo : CustomerInfo) -> Bool{
        
        sharedInstance.database!.open()
        let isInserted = sharedInstance.database!.executeUpdate("INSERT INTO CUSTOMERS (NAME,AGE,ADDRESS,SALARY) VALUES (?,?,?,?)",withArgumentsIn: [custInfo.custName, custInfo.custAge,custInfo.custAddress,custInfo.custSalary])
        sharedInstance.database!.close()
        return isInserted
    }
    
    func addOrderData(orderinfo : Orderinfo) -> Bool{
        sharedInstance.database!.open()
        let isInserted = sharedInstance.database!.executeUpdate("INSERT INTO ORDERS (DATE,CUSTOMER_ID,AMOUNT) VALUES (?,?,?)",withArgumentsIn: [orderinfo.orderDate,orderinfo.cust_id,orderinfo.amount])
        sharedInstance.database!.close()
        return isInserted
    }
    
    func getCustomerdata() -> NSMutableArray {
        sharedInstance.database!.open()
        
        let resultSet : FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM CUSTOMERS", withArgumentsIn: [])
        let marrStudentInfo : NSMutableArray = NSMutableArray()
        if (resultSet != nil) {
            while resultSet.next() {
                
                let customerinfo : CustomerInfo = CustomerInfo()
                customerinfo.custid = Int(resultSet.int(forColumn: "ID"))
                customerinfo.custName = resultSet.string(forColumn: "NAME")!
                customerinfo.custAge = Int(resultSet.int(forColumn: "AGE"))
                customerinfo.custSalary = Float(resultSet.double(forColumn: "SALARY"))
                customerinfo.custAddress = resultSet.string(forColumn: "ADDRESS")!
                marrStudentInfo.add(customerinfo)
                
            }
        }
        sharedInstance.database!.close()
        return marrStudentInfo
    }
    func getOrderdata() -> NSMutableArray {
        sharedInstance.database!.open()
        
        let resultSet : FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM ORDERS", withArgumentsIn: [])
        let marrStudentInfo : NSMutableArray = NSMutableArray()
        if (resultSet != nil) {
            while resultSet.next() {
                let orderdata : Orderinfo = Orderinfo()
                orderdata.cust_id = Int(resultSet.int(forColumn: "CUSTOMER_ID"))
                orderdata.amount =  Float(resultSet.double(forColumn: "AMOUNT"))
                orderdata.orderDate = resultSet.date(forColumn: "DATE")! as NSDate
                marrStudentInfo.add(orderdata)
                
            }
        }
        sharedInstance.database!.close()
        return marrStudentInfo
    }
    
    func getCustOrderdata() -> NSMutableArray{
        
        sharedInstance.database!.open()
        let resultSet : FMResultSet! = sharedInstance.database!.executeQuery("SELECT ID, NAME, SALARY FROM CUSTOMERS WHERE SALARY > 2000 AND age < 25", withArgumentsIn: [])
       // let resultSet : FMResultSet! = sharedInstance.database!.executeQuery("SELECT ID, NAME, AGE, AMOUNT FROM  CUSTOMERS,ORDERS WHERE CUSTOMERS.ID = ORDERS.CUSTOMER_ID", withArgumentsIn: [])
        let marrStudentInfo : NSMutableArray = NSMutableArray()
        if (resultSet != nil) {
            while resultSet.next() {
                let orderdata : Orderinfo = Orderinfo()
                
                //orderdata.orderDate = //resultSet.date(forColumn: "DATE")! as NSDate
                //orderdata.cust_id = Int(resultSet.int(forColumn: "CUSTOMER_ID"))
                orderdata.cust_name = resultSet.string(forColumn: "NAME")!
                orderdata.amount =  Float(resultSet.double(forColumn: "AMOUNT"))
                
                marrStudentInfo.add(orderdata)
                
            }
        }
        sharedInstance.database!.close()
        return marrStudentInfo
    }

    /*
       
    func updateStudentData(studentInfo: StudentInfo) -> Bool {
        sharedInstance.database!.open()
        let isUpdated = sharedInstance.database!.executeUpdate("UPDATE student_info SET Name=?, Marks=? WHERE RollNo=?", withArgumentsInArray: [studentInfo.Name, studentInfo.Marks, studentInfo.RollNo])
        sharedInstance.database!.close()
        return isUpdated
    }
    
    func deleteStudentData(studentInfo: StudentInfo) -> Bool {
        sharedInstance.database!.open()
        let isDeleted = sharedInstance.database!.executeUpdate("DELETE FROM student_info WHERE RollNo=?", withArgumentsInArray: [studentInfo.RollNo])
        sharedInstance.database!.close()
        return isDeleted
    }
 */
}
