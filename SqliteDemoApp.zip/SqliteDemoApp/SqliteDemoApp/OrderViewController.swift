//
//  OrderViewController.swift
//  SqliteDemoApp
//
//  Created by Manish Surti on 15/07/2017.
//  Copyright © 2017 ASquare.com. All rights reserved.
//

import UIKit

class OrderViewController: UIViewController {

    @IBOutlet weak var txtcustId: UITextField!
    @IBOutlet weak var txtdata: UITextField!
    @IBOutlet weak var txtamount: UITextField!
    
    var orderArray : NSMutableArray = NSMutableArray()
    var ordersArray : NSMutableArray = NSMutableArray()
    override func viewDidLoad() {
        super.viewDidLoad()

      
    }
    
    @IBAction func OrderAction(_ sender: Any) {
        
        let orderinfo: Orderinfo = Orderinfo()
        orderinfo.cust_id = Int(txtcustId.text!)!
        orderinfo.orderDate = NSDate()
        orderinfo.amount = Float(txtamount.text!)!
        let isInserted = ModelManager.getInstance().addOrderData(orderinfo: orderinfo)
        if isInserted {
            Util.invokeAlertMethod(strTitle: "", strBody: "Record Inserted successfully.", delegate: nil)
        } else {
            Util.invokeAlertMethod(strTitle: "", strBody: "Error in inserting record.", delegate: nil)
        }
    }
    @IBAction func ShowData(_ sender: Any) {
        
        orderArray = ModelManager.getInstance().getOrderdata()
        
        for i in 0..<orderArray.count{
            
            let orderinfos : Orderinfo = orderArray.object(at: i) as! Orderinfo
            print(orderinfos.orderDate ,orderinfos.amount,orderinfos.cust_id)
            
        }
        
        print("Join query Data::")
        
        ordersArray = ModelManager.getInstance().getCustOrderdata()
        for i in 0..<ordersArray.count{
            
            let orderinfos : Orderinfo = ordersArray.object(at: i) as! Orderinfo
            
            print("\n",orderinfos.cust_name, " " ,orderinfos.amount)
            
            
            
        }
 
        
    }


}
