//
//  Orderinfo.swift
//  SqliteDemoApp
//
//  Created by Manish Surti on 15/07/2017.
//  Copyright © 2017 ASquare.com. All rights reserved.
//

import UIKit

class Orderinfo: NSObject {
    
    var orderDate : NSDate = NSDate()
    var cust_id : Int = Int()
    var amount : Float = Float()
    var cust_name : String = String()
}
