//
//  ViewController.swift
//  SqliteDemoApp
//
//  Created by Manish Surti on 15/07/2017.
//  Copyright © 2017 ASquare.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var customerArray : NSMutableArray = NSMutableArray()
    override func viewDidLoad() {
        super.viewDidLoad()
      
        
    }

   

}

